#!/usr/bin/python
import struct
import sys
import core
import time
import base64 as b64

###############################
def l05_hash(data, mask=0x7F):
    #Forcing 32b arith by &0xFFFFFFFF
    h = 0xfee13117
    h &= 0xFFFFFFFF
    for ch in data:
        h ^= ord(ch)
        h &= 0xFFFFFFFF
        h += h<<11
        h &= 0xFFFFFFFF
        h ^= h>>7
        h &= 0xFFFFFFFF
        h -= ord(ch)
        h &= 0xFFFFFFFF
    h += h<<3
    h &= 0xFFFFFFFF
    h ^= h>>10
    h &= 0xFFFFFFFF
    h += h<<15
    h &= 0xFFFFFFFF
    h -= h>>17
    h &= 0xFFFFFFFF
    return h & mask


###############################
def isup(fd):
    return True

def quit(fd):
    fd.send("quit")
    return True

def checkname(fd, name):
    cmd = "checkname"
    buf = " ".join([cmd, str(name)])
    fd.send(buf)
    print fd.recv(1024)
    return True

def senddb(fd, ip, port):
    cmd = "senddb"
    buf = " ".join([cmd, str(ip), str(port), "\r\n\x00"])
    fd.send(buf)
    return True

#Set regindex if you'd like to force your entry into a specific reg[index]
#Name will be ignored if regindex is set.
def addreg(fd, name, flags, ip, regindex=None):
    if regindex is not None:
        for i in xrange(sys.maxint):
            if l05_hash(str(i)) == regindex:
                name=str(i)
                break
        print "Updating NAME=\"{0}\" to hit REG[{1}]".format(name, regindex)

    cmd = "addreg"
    buf = " ".join([cmd, str(name), str(int(flags)), str(ip)])
    fd.send(buf)
    return True #Printf appears to not route over socket!

def main(fd):
    print core.rx_until(fd, "\n") #Welcome to level05

	#YOUR CODE HERE!

if __name__ == "__main__":
    if len(sys.argv) > 2:
        ip = sys.argv[1]
        port = int(sys.argv[2])
    else:
        print "Assigning default IP/PORT"
        ip = "192.168.136.130"
        port = 20005
        fd = core.attach(ip, port, wait=True)
    main(fd)
